package sv.edu.udb.util;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import sv.edu.udb.domain.Persona;


/**
 * Clase que contiene los métodos de SELECT, INSERT, UPDATE y DELETE para la
 * tabla de estudiantesudbvirtual en MYSQL
 *
 * @author Ubaldo
 *
 */
public class EstudiantesCRUD {
    //Nos apoyamos de la llave primaria autoincrementable de MySql
    //por lo que se omite el campo de persona_id
    //Se utiliza un prepareStatement, por lo que podemos
    //utilizar parametros (signos de ?)
    //los cuales posteriormente será sustituidos por el parametro respectivo
    private final String SQL_INSERT
    = "INSERT INTO estudiantesudbvirtual(carnet,nombres, apellido1,apellido2,edad) VALUES(?,?,?,?,?)";
    private final String SQL_UPDATE
    = "UPDATE estudiantesudbvirtual SET nombres=?, apellido1=?, apellido2=?, edad=? WHERE carnet=?";
    private final String SQL_DELETE
    = "DELETE FROM estudiantesudbvirtual WHERE carnet = ?";
    private final String SQL_SELECT
    = "SELECT carnet,nombres, apellido1,apellido2,edad FROM estudiantesudbvirtual ORDER BY carnet";

    /**
     * Metodo que inserta un registro en la tabla de Persona
     * @param carnet
     * @param nombres
     * @param apellido1
     * @param apellido2
     * @param edad
     */
    public int insert(String carnet,String nombres,String apellido1,String apellido2,int edad) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;//no se utiliza en este ejercicio		
        int rows = 0; //registros afectados
        try {
            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_INSERT);
            int index = 1;//contador de columnas
            stmt.setString(index++, carnet);//param 1 => ?
            stmt.setString(index++, nombres);//param 2 => ?
            stmt.setString(index++, apellido1);//param 2 => ?
            stmt.setString(index++, apellido2);//param 2 => ?
            stmt.setInt(index, edad);//param 2 => ?
            System.out.println("Ejecutando query:" + SQL_INSERT);
            rows = stmt.executeUpdate();//no. registros afectados
            System.out.println("Registros afectados:" + rows);

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            Conexion.close(stmt);
            Conexion.close(conn);
        }
        return rows;
    }

    /**
     * Metodo que actualiza un registro existente
     *
     * @param carnet
     * @param nombres
     * @param apellido1
     * @param apellido2
     * @param edad
     * @return int No. de registros modificados
     */
    public int update(String carnet,String nombres,String apellido1,String apellido2,int edad) {
        Connection conn = null;
        PreparedStatement stmt = null;
        int rows = 0;
        try {
            conn = Conexion.getConnection();
            System.out.println("Ejecutando query:" + SQL_UPDATE);
            stmt = conn.prepareStatement(SQL_UPDATE);
            int index = 1;
            stmt.setString(index++, carnet);//param 1 => ?
            stmt.setString(index++, nombres);//param 2 => ?
            stmt.setString(index++, apellido1);//param 2 => ?
            stmt.setString(index++, apellido2);//param 2 => ?
            stmt.setInt(index, edad);//param 2 => ?
            rows = stmt.executeUpdate();
            System.out.println("Registros actualizados:" + rows);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            Conexion.close(stmt);
            Conexion.close(conn);
        }
        return rows;
    }

    /**
     * Metodo que elimina un registro existente
     *
     * @param id_persona Es la llave primaria
     * @return int No. registros afectados
     */
    public int delete(String carnet) {
        Connection conn = null;
        PreparedStatement stmt = null;
        int rows = 0;
        try {
            conn = Conexion.getConnection();
            System.out.println("Ejecutando query:" + SQL_DELETE);
            stmt = conn.prepareStatement(SQL_DELETE);
            stmt.setString(1, carnet);
            rows = stmt.executeUpdate();
            System.out.println("Registros eliminados:" + rows);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            Conexion.close(stmt);
            Conexion.close(conn);
        }
        return rows;
    }

    /**
     * Metodo que regresa el contenido de la tabla de estudiantes
     */
   /**
     * Metodo que regresa el contenido de la tabla de personas
     */
    public List<Persona> select() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Persona persona = null;
        List<Persona> personas = new ArrayList<Persona>();
        try {
            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_SELECT);
            rs = stmt.executeQuery();
            while (rs.next()) {
                persona = new Persona();
                persona.setCarne(rs.getString(1));
                persona.setNombres(rs.getString(2));
                persona.setPrimerApellido(rs.getString(3));
                persona.setSegundoApellido(rs.getString(4));
                persona.setEdad(rs.getString(5));
                personas.add(persona);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            Conexion.close(rs);
            Conexion.close(stmt);
            Conexion.close(conn);
        }
        return personas;
    }
}