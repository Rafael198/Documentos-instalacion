/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sv.edu.udb.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import sv.edu.udb.domain.Persona;
import sv.edu.udb.util.EstudiantesCRUD;

/**
 *
 * @author User
 */
@WebServlet(name = "IngresoEstudiantes", urlPatterns = {"/IngresoEstudiantes"})
public class IngresoEstudiantes extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet IngresoEstudiantes</title>");  
             out.println("</head>");
            out.println("<body>");
            String carnet;
            String nombres;
            String primerApellido;
            String segundoApellido;
            String edad;
            String salida;

            carnet          = request.getParameter("carne");
            nombres         = request.getParameter("nombres");
            primerApellido  = request.getParameter("apellido1");
            segundoApellido = request.getParameter("apellido2");
            edad            = request.getParameter("edad");

            EstudiantesCRUD estudianteJDBC = new EstudiantesCRUD();
            if (estudianteJDBC.insert(carnet, nombres, primerApellido, segundoApellido, Integer.parseInt(edad)) >= 1){
                salida  = "<b>Alumno Ingresado Exitosamente</b>";  
                out.println(salida);
                out.println("<table with='75%' border=1>");
                out.println("<tr><th>Carné</th><th>Nombres</th><th>Apellidos</th><th>Edad</th></tr>");
                for (Persona persona : estudianteJDBC.select()) {
                       out.println("<tr><td>"+persona.getCarne()+"</td>"+
                       "<td>"+persona.getNombres()+"</td>"+
                       "<td>"+persona.getPrimerApellido()+
                       persona.getSegundoApellido()+"</td>"+
                       "<td>"+persona.getEdad()+"</td></tr>");
                }
                out.println("</table>");
            }else{
                salida  = "<html><body><b>Error con el Ingreso de Alumno</b> </body></html>"; 
            }
        
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
